import { chmod, unlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import type { LoadedConfig } from "./config.ts";
import type { DeployPlan } from "./planner.ts";
import type { ContainerSpec } from "./adapters/types.ts";
import { groupLabels } from "./planner.ts";
import { NETWORK } from "./commands/docker.ts";
import { serviceId as legacyServiceId } from "./commands/proxy.ts";
import { defaultControlDir } from "./host/session.ts";
import { LocalExecutor } from "./exec/local.ts";
import { SshExecutor, connectOptionsFor } from "./exec/ssh.ts";
import { connectionForTarget } from "./hosts.ts";
import { acquireLock, releaseLock } from "./lock.ts";
import { openOps, type OpsVia, type PullPolicy, type RuntimeOps } from "./ops/index.ts";
import { preflightGate } from "./validation.ts";

export interface DeployOptions {
  /** Execution path for mutations: API (default) or the legacy CLI strings. */
  via?: OpsVia;
  /** Test seam: the factory runs only after preflight passes. */
  openPrimary?: () => SshExecutor;
  /** v2: allow two units that differ only by case. */
  allowCaseCollision?: boolean;
  /** missing (default) skips a pull when the image is present. */
  pullPolicy?: PullPolicy;
  /** Per-phase milliseconds, written for --timings / --json. */
  phases?: Record<string, number>;
}

export interface DeployOnHostOptions {
  host: string;
  /** Local merged env file (legacy uploads it; the API path does not). */
  envLocalFile?: string | null;
  /** Legacy --local-image pipeline, when the CLI path is forced. */
  localPushPipeline?: string;
  allowCaseCollision?: boolean;
  pullPolicy?: PullPolicy;
  phases?: Record<string, number>;
}

function timed(phases: Record<string, number> | undefined, phase: string, start: number): void {
  if (phases !== undefined) phases[phase] = (phases[phase] ?? 0) + performance.now() - start;
}

/** Apply the image pull policy through RuntimeOps. */
export async function pullForPolicy(
  ops: Pick<RuntimeOps, "imagePresent" | "pull">,
  image: string,
  policy: PullPolicy,
): Promise<"pulled" | "present"> {
  const present = await ops.imagePresent(image);
  if (policy === "never") {
    if (!present) throw new Error("image not present on host: " + image + " (--pull never)");
    return "present";
  }
  if (policy === "always" || !present) {
    await ops.pull(image);
    return "pulled";
  }
  return "present";
}

export interface ExistingUnit {
  name: string;
  labels: Record<string, string>;
}

/**
 * Case-only duplicates are unsafe on case-insensitive DNS/hosts. Compare the
 * host's labelled units by (group, service), not by full container name: a
 * redeploy changes the revision, which would hide the collision.
 */
export function findCaseCollision(
  rows: ExistingUnit[],
  planned: { group?: string; service: string },
): string | undefined {
  const group = planned.group !== undefined && planned.group !== "" ? planned.group : "default";
  const unit = group + "/" + planned.service;
  for (const row of rows) {
    const rowGroup = row.labels["bundant.group"];
    const rowService = row.labels["bundant.service"];
    if (rowGroup === undefined || rowService === undefined) continue;
    if (rowGroup.toLowerCase() !== group.toLowerCase()) continue;
    if (rowService.toLowerCase() !== planned.service.toLowerCase()) continue;
    if (rowGroup === group && rowService === planned.service) continue;
    const existing = rowGroup + "/" + rowService;
    return existing + " and " + unit + " both resolve to " + unit.toLowerCase();
  }
  return undefined;
}

/** Turn a merged KEY=VAL file into the engine's Env array (values stay redacted in logs). */
export function envArray(content: string | null): string[] {
  if (content === null || content.trim() === "") return [];
  const out: string[] = [];
  for (const line of content.split("\n")) {
    const text = line.trim();
    if (text === "" || text.startsWith("#")) continue;
    const eq = text.indexOf("=");
    if (eq <= 0) continue;
    out.push(text.slice(0, eq) + "=" + text.slice(eq + 1));
  }
  return out;
}

/**
 * One host's deploy on top of RuntimeOps. The ordering is the zero-downtime
 * contract: create + start the new revision, gate it, swap the proxy target
 * set once, then stop the old revision. Any failure removes only what this
 * run started and leaves traffic on the old revision.
 */
export async function deployOnHost(
  ops: RuntimeOps,
  plan: DeployPlan,
  loaded: LoadedConfig,
  opts: DeployOnHostOptions,
): Promise<void> {
  const m = plan.meta;
  const host = opts.host;
  const env = envArray(loaded.envContent);

  const rows = await ops.listContainers({ all: true });
  if (opts.allowCaseCollision !== true) {
    const collision = findCaseCollision(rows, {
      group: loaded.config.group,
      service: loaded.config.service,
    });
    if (collision !== undefined) throw new Error("case-collision: " + collision);
  }
  const existingNames = new Set(rows.map((row) => row.name));

  await ops.putEnv(opts.envLocalFile ?? null, m.envRemotePath, loaded.envCount);
  if (
    ops.via === "cli" &&
    opts.envLocalFile !== undefined &&
    opts.envLocalFile !== null &&
    m.envRemotePath !== undefined
  ) {
    console.log("[" + host + "] env uploaded (" + loaded.envCount + " vars, redacted)");
  }

  const prereqStart = performance.now();
  await ops.hostPrereqs();
  timed(opts.phases, "connect", prereqStart);
  if (opts.localPushPipeline !== undefined) {
    const r = await new LocalExecutor().run(opts.localPushPipeline.replaceAll("{HOST}", host));
    if (r.code !== 0) {
      throw new Error("[" + host + "] push-image failed: " + (r.stderr.trim() || r.stdout.trim()));
    }
    console.log("[" + host + "] push-image ok: " + r.stdout.trim());
  } else {
    const policy = opts.pullPolicy ?? "missing";
    const pullStart = performance.now();
    const pull = await pullForPolicy(ops, m.image, policy);
    timed(opts.phases, "pull", pullStart);
    console.log(
      "[" + host + "] " +
        (pull === "pulled" ? "pull ok (policy=" + policy + ")" : "pull skipped (present, policy=" + policy + ")"),
    );
  }

  const networkStart = performance.now();
  await ops.ensureNetwork();
  timed(opts.phases, "network", networkStart);
  console.log("[" + host + "] network ok");

  const created: string[] = [];
  const createStart = performance.now();
  try {
    for (let i = 0; i < m.containerNames.length; i++) {
      const name = m.containerNames[i]!;
      const spec: ContainerSpec = {
        image: m.image,
        name,
        env,
        labels: groupLabels(loaded.config, m.revision, i + 1),
        network: NETWORK,
        restart: "unless-stopped",
      };
      created.push(name);
      // Only the same revision already on the host needs the rm -f; a brand new
      // revision skips a 404 round-trip.
      if (existingNames.has(name)) await ops.removeContainer(name, { force: true });
      const id = await ops.createContainer(spec);
      await ops.startContainer(id);
    }
    timed(opts.phases, "create", createStart);
    console.log("[" + host + "] run ok: " + m.containerNames.join(", "));

    const healthStart = performance.now();
    await ops.healthGate(m.containerNames, {
      path: m.healthcheck.path,
      port: m.healthcheck.port,
      timeoutMs: m.healthcheck.timeout * 1000,
    });
    timed(opts.phases, "health", healthStart);
    console.log("[" + host + "] health gate passed (" + m.containerNames.length + " target(s))");

    if (loaded.config.proxy.enabled) {
      const proxyStart = performance.now();
      await ops.proxyEnsure(loaded.config.proxy.image);
      console.log("[" + host + "] proxy-ensure ok");
      const targets = m.containerNames.map(
        (n) => n + ":" + loaded.config.proxy.port,
      );
      const proxyOpts = {
        host: loaded.config.proxy.host,
        tls: loaded.config.proxy.tls,
        healthCheckPath: loaded.config.healthcheck.path,
        healthCheckPort:
          loaded.config.healthcheck.port === loaded.config.proxy.port
            ? undefined
            : loaded.config.healthcheck.port,
      };
      const legacyId = legacyServiceId(
        loaded.config.service,
        loaded.config.role,
        loaded.config.group,
      );
      const routes = legacyId !== m.serviceId ? await ops.proxyList() : [];
      if (routes.includes(legacyId)) {
        // v1 -> v2 route id change. The proxy refuses two services on one host,
        // so serve the new id as a wildcard first, then drop the old id.
        await ops.proxyDeploy(m.serviceId, targets, { ...proxyOpts, host: undefined });
        await ops.proxyRemove(legacyId);
        await ops.proxyDeploy(m.serviceId, targets, proxyOpts);
        console.log("[" + host + "] proxy-swap ok (migrated " + legacyId + " -> " + m.serviceId + ")");
      } else {
        await ops.proxyDeploy(m.serviceId, targets, proxyOpts);
        console.log("[" + host + "] proxy-swap ok");
      }
      timed(opts.phases, "proxy", proxyStart);
    }

    const stopStart = performance.now();
    await ops.stopOld(loaded.config, m.containerNames);
    timed(opts.phases, "stop-old", stopStart);
    console.log("[" + host + "] stop-old ok");
  } catch (e) {
    for (const name of created) {
      try {
        await ops.removeContainer(name, { force: true });
      } catch {
        // best-effort cleanup; the original failure is the useful error
      }
    }
    console.log(
      "[" + host + "] aborted, removed containers started by this run (" +
        created.join(", ") + ")",
    );
    throw e;
  }
}

/** Orchestrates the planned sequence per host under the hosts[0] deploy lock. */
export async function deploy(
  plan: DeployPlan,
  loaded: LoadedConfig,
  opts: DeployOptions = {},
): Promise<number> {
  const m = plan.meta;
  // Image streaming is still stage 4 work: keep the whole run on the CLI path.
  const via: OpsVia = m.localImage !== undefined ? "cli" : (opts.via ?? "api");
  if (m.localImage !== undefined && opts.via === "api") {
    console.log("note: --local-image still uses the CLI path (stage 4 moves image streaming)");
  }

  // Preflight first: an invalid config must never create a connection or a lock.
  const preflightStart = performance.now();
  const primary = preflightGate(loaded, () =>
    opts.openPrimary !== undefined
      ? opts.openPrimary()
      : new SshExecutor({
          ...connectOptionsFor(connectionForTarget(loaded.config, m.hosts[0]!)),
          controlDir: defaultControlDir(),
          controlPersistSec: 60,
          persist: true,
        }),
  );
  timed(opts.phases, "preflight", preflightStart);
  const execs = new Set<SshExecutor>([primary]);
  let locked = false;

  let envLocalFile: string | null = null;
  // The API path sends Env in the create request; only the legacy path needs a
  // local staging file (and therefore a host-side upload).
  if (via === "cli" && loaded.envContent && m.envRemotePath) {
    envLocalFile = tmpdir() + "/bundant-" + m.service + "-" + m.role + ".env";
    await writeFile(envLocalFile, loaded.envContent, { mode: 0o600 });
    await chmod(envLocalFile, 0o600);
  }

  const local = m.localImage ? new LocalExecutor() : null;
  const pushStep = plan.hostSteps.find((s) => s.phase === "push-image");

  try {
    if (m.localImage && local) {
      const rt = loaded.config.runtime;
      const check = await local.run(rt + " image inspect " + m.localImage + " >/dev/null 2>&1");
      if (check.code !== 0) {
        throw new Error(
          "local image not found: " + m.localImage + " — build or pull it first (" + rt + " images)",
        );
      }
    }

    const lockStart = performance.now();
    await acquireLock(primary, m.lockKey);
    timed(opts.phases, "lock", lockStart);
    // A second exec on the same connection measures reuse (not the handshake,
    // which the lock call above already paid).
    const sshStart = performance.now();
    await primary.run("true");
    timed(opts.phases, "ssh", sshStart);
    locked = true;
    console.log(
      "deploy " + m.service + "/" + m.role + " rev=" + m.revision + " -> " +
        m.hosts.join(", ") + " (via " + via + ")",
    );

    for (const host of m.hosts) {
      console.log("[" + host + "] deploying " + m.containerNames.join(", "));
      const connectStart = performance.now();
      const ops = await openOps(via, connectionForTarget(loaded.config, host), loaded.config, {
        envRemotePath: m.envRemotePath,
      });
      timed(opts.phases, "connect", connectStart);
      try {
        await deployOnHost(ops, plan, loaded, {
          host,
          envLocalFile,
          localPushPipeline: pushStep?.cmds[0],
          allowCaseCollision: opts.allowCaseCollision,
          pullPolicy: opts.pullPolicy,
          phases: opts.phases,
        });
      } finally {
        const closeStart = performance.now();
        await ops.close();
        timed(opts.phases, "disconnect", closeStart);
      }
    }

    console.log(
      "deployed " + m.containerNames.join(", ") + " on " + m.hosts.length + " host(s)",
    );
    return 0;
  } finally {
    const releaseStart = performance.now();
    if (locked) await releaseLock(primary, m.lockKey);
    for (const e of execs) await e.close();
    timed(opts.phases, "release", releaseStart);
    if (envLocalFile !== null) await unlink(envLocalFile).catch(() => {});
  }
}
